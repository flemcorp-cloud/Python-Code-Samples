#!/usr/bin/env python

# Author: Hezekiah Watson
# Last Edit: February 12, 2025

# A program that will loop to print each number on a new line.

# List of numbers
numbers = [12, 10, 32, 3, 66, 17, 42, 99, 20]

# Loop through each number in the list
for number in numbers:
    # Print each number on a new line
    print(number)
