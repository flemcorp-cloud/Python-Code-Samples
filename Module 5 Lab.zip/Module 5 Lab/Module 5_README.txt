The folder contains the Python program files for Module 5.

Student: Hezekiah Watson

Course: CSS 225

School: National Louis University

File names: 

Module 5 Lab activity flowcharts.docx

divisible_numbers.py

Hello_World_100 Times.py

number and square.py

print_numbers.py

regular polygon.py

turtle_house.py



