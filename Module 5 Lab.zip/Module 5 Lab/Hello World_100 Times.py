#!/usr/bin/env python

# Author: Hezekiah Watson
# Last Edit: February 12, 2025
# A program that will print "Hello World" 100 times

# Start a for loop that will repeat 100 times
for i in range(100):  
    # Print "Hello World" to the screen each time the loop runs
    print("Hello World")
